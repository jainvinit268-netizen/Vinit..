const BANK = Array.isArray(window.EDUNITI_BANK) ? window.EDUNITI_BANK : [];

    const LS_BK = 'eduniti_rv_bookmarks_v1';
    const LS_ATT = 'eduniti_rv_attempts_v1';

    const state = {
      segment: 'by_chapter',
      search: '',
      pendingSet: null,
      pendingMode: 'practice',
      pendingUi: 'nta',
      session: {
        mode: 'practice',
        uiStyle: 'nta',
        title: '',
        questions: [],
        idx: 0,
        responses: {},
        statuses: {},
        revealed: {},
        qTimes: {},
        seconds: 0,
        totalSeconds: 0,
        invertPractice: true,
        ntaUiDark: false,
        ntaQDark: false,
        timerId: null
      },
      analysisSub: 'overview',
      solIdx: 0,
      activeAttempt: null
    };

    const $ = (id) => document.getElementById(id);
    const fmtMMSS = (s) => `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
    const fmtHuman = (s) => s >= 60 ? `${Math.floor(s / 60)}m ${s % 60}s` : `${s}s`;

    function toast(msg, type = 'info') {
      const el = document.createElement('div');
      const cls = type === 'success' ? 'bg-emerald-950/95 border-emerald-500/40 text-emerald-200'
                : type === 'warn' ? 'bg-amber-950/95 border-amber-500/40 text-amber-200'
                : 'bg-slate-900/95 border-indigo-500/40 text-indigo-200';
      el.className = `px-3.5 py-2 rounded-xl border text-xs font-semibold shadow-xl anim-in ${cls}`;
      el.textContent = msg;
      $('toastBox').appendChild(el);
      setTimeout(() => el.remove(), 2600);
    }

    function getBks() { try { return JSON.parse(localStorage.getItem(LS_BK) || '[]'); } catch { return []; } }
    function setBks(arr) {
      try { localStorage.setItem(LS_BK, JSON.stringify(arr)); } catch {}
      $('bnavBkCount').textContent = arr.length;
    }
    function isBk(id) { return getBks().some(x => x.id === id); }
    function toggleBk(q) {
      let arr = getBks();
      const i = arr.findIndex(x => x.id === q.id);
      if (i >= 0) { arr.splice(i, 1); toast('Removed from Bookmarks'); }
      else { arr.unshift(q); toast('Saved to Important Bookmarks!', 'success'); }
      setBks(arr);
    }

    function getAttempts() { try { return JSON.parse(localStorage.getItem(LS_ATT) || '[]'); } catch { return []; } }
    function saveAttempt(rec) {
      const arr = getAttempts();
      arr.unshift(rec);
      try { localStorage.setItem(LS_ATT, JSON.stringify(arr.slice(0, 20))); } catch {}
    }

    function showView(name) {
      document.querySelectorAll('.app-view').forEach(v => v.classList.add('hidden'));
      const el = $(`view-${name}`);
      if (el) el.classList.remove('hidden');

      const hideChrome = (name === 'cbt' || name === 'practice' || name === 'instructions');
      $('mainHeader').classList.toggle('hidden', hideChrome);
      $('bottomNav').classList.toggle('hidden', hideChrome);

      document.querySelectorAll('.bnav-btn').forEach(b => {
        const act = b.dataset.view === name;
        b.className = `bnav-btn relative flex items-center justify-center gap-1.5 py-1.5 rounded-xl text-xs transition ${
          act ? 'font-bold bg-indigo-600/20 text-sky-300 border border-indigo-500/40' : 'font-semibold text-slate-400'
        }`;
      });
      if (name === 'folders') renderFolders();
      if (name === 'bookmarks') renderBookmarks();
      if (name === 'analysis') renderAnalysis();
      if (window.lucide) lucide.createIcons();
    }

    // ==================== FOLDERS (RANKVORTEX 57013.jpg STYLE) ====================
    function buildRows() {
      const qTxt = state.search.trim().toLowerCase();
      if (state.segment === 'by_chapter') {
        const cmap = new Map();
        BANK.forEach(ch => {
          ch.questions.forEach(q => {
            const c = q.chapter || q.subject || 'Physics';
            if (!cmap.has(c)) cmap.set(c, []);
            cmap.get(c).push({ ...q, subject: `${c} • ${ch.tag || 'PYQ'}` });
          });
        });
        return Array.from(cmap.entries())
          .filter(([c]) => !qTxt || c.toLowerCase().includes(qTxt))
          .map(([c, qs]) => ({
            title: c,
            subtitle: `${qs.length} Qs • All Challenges Combined`,
            mins: Math.max(15, Math.round(qs.length * 2)),
            questions: qs
          }));
      }
      return BANK.filter(ch => ch.folder === state.segment && (!qTxt || ch.title.toLowerCase().includes(qTxt)))
        .map(ch => ({
          title: ch.title,
          subtitle: `${ch.questions.length} Qs • ${ch.tag || 'Eduniti'}`,
          mins: Math.max(15, Math.round(ch.questions.length * 2)),
          questions: ch.questions.map(q => ({ ...q, subject: q.chapter || ch.title }))
        }));
    }

    function renderFolders() {
      const rows = buildRows();
      const headLabel = state.segment === 'by_chapter' ? 'Physics Chapters (All Challenges Combined)'
                      : state.segment === 'jee_challenges' ? 'JEE Main Challenges (2019–2026)' : 'Selected HCV Chapters';
      const totalQs = rows.reduce((a, r) => a + r.questions.length, 0);

      $('folderListContainer').innerHTML = `
        <div class="px-4 py-3.5 bg-indigo-950/50 border-b border-slate-800 flex items-center justify-between">
          <div>
            <div class="text-sm font-extrabold text-white">${headLabel}</div>
            <div class="text-[11px] text-slate-400">${rows.length} sets · ${totalQs} questions</div>
          </div>
          <span class="w-7 h-7 rounded-full bg-indigo-600 text-white text-xs font-bold flex items-center justify-center">${rows.length}</span>
        </div>
        <div class="divide-y divide-slate-800/80">
          ${rows.length === 0 ? `<div class="p-8 text-center text-sm text-slate-500">No matching sets found.</div>` : rows.map((r, i) => `
            <div class="grid grid-cols-12 items-stretch hover:bg-slate-900/50 transition">
              <div class="col-span-7 sm:col-span-8 p-3.5 flex items-center gap-3 min-w-0">
                <span class="w-8 h-8 rounded-xl bg-violet-600 text-white font-mono text-xs font-extrabold flex items-center justify-center shrink-0">${i + 1}</span>
                <div class="min-w-0">
                  <div class="text-xs sm:text-sm font-bold text-white truncate">${r.title}</div>
                  <div class="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                    <span>${r.questions.length} Qs</span>
                    <span>• ${r.mins} min</span>
                  </div>
                  <div class="flex flex-wrap items-center gap-1.5 mt-1">
                    <span class="inline-block px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 text-[10px] font-bold">Official Keys</span>
                    ${(() => {
                      const prev = getAttempts().filter(a => a.title === r.title);
                      if (!prev.length) return '';
                      const last = prev[0];
                      return `<button type="button" data-hist-title="${r.title}" class="row-hist-btn px-2 py-0.5 rounded bg-indigo-500/20 hover:bg-indigo-500/35 text-indigo-300 border border-indigo-500/30 text-[10px] font-bold">${prev.length} Prev • Last: ${last.score ?? 0}/${last.maxScore ?? (r.questions.length * 4)}</button>`;
                    })()}
                  </div>
                </div>
              </div>
              <button data-ridx="${i}" class="row-prac-btn col-span-2 sm:col-span-2 border-l border-slate-800/80 flex flex-col items-center justify-center px-1 hover:bg-emerald-500/10 transition active:scale-95">
                <span class="text-[11px] font-extrabold text-emerald-400">Practice</span>
                <span class="text-[10px] text-emerald-400/75">Mode</span>
              </button>
              <button data-ridx="${i}" class="row-cbt-btn col-span-3 sm:col-span-2 border-l border-slate-800/80 flex flex-col items-center justify-center px-1 hover:bg-amber-500/10 transition active:scale-95">
                <span class="text-[11px] font-extrabold text-amber-400">CBT</span>
                <span class="text-[10px] text-amber-400/75">Mode</span>
              </button>
            </div>
          `).join('')}
        </div>
      `;

      $('folderListContainer').querySelectorAll('.row-prac-btn').forEach(b => {
        b.onclick = () => openUiChoice(rows[parseInt(b.dataset.ridx, 10)], 'practice');
      });
      $('folderListContainer').querySelectorAll('.row-cbt-btn').forEach(b => {
        b.onclick = () => openUiChoice(rows[parseInt(b.dataset.ridx, 10)], 'cbt');
      });
      $('folderListContainer').querySelectorAll('.row-hist-btn').forEach(b => {
        b.onclick = (e) => {
          e.stopPropagation();
          const t = b.dataset.histTitle;
          const matches = getAttempts().filter(a => a.title === t);
          if (matches.length) {
            state.activeAttempt = matches[0];
            state.analysisSub = 'overview';
            state.solIdx = 0;
            showView('analysis');
          }
        };
      });
    }

    // ==================== NTA INSTRUCTIONS & SESSION ENGINE ====================
    function openUiChoice(setObj, mode) {
      state.pendingSet = setObj;
      state.pendingMode = mode;
      $('uiModalBadge').textContent = mode === 'practice' ? 'Practice Mode' : 'CBT Test Mode';
      $('uiModalTitle').textContent = setObj.title;
      $('uiModalSub').textContent = `${setObj.questions.length} Questions • Choose Classic NTA UI or Modern Dark UI`;
      $('uiChoiceModal').classList.remove('hidden');
    }

    function openInstructions(setObj, uiStyle = 'nta') {
      state.pendingSet = setObj;
      state.pendingUi = uiStyle;
      $('instTitle').textContent = setObj.title;
      $('instMeta').textContent = `${setObj.questions.length} Questions • ${setObj.mins} Minutes • +4 / -1 Marking (${uiStyle === 'nta' ? 'Classic NTA UI' : 'Modern Dark UI'})`;
      showView('instructions');
    }

    function startSession(setObj, mode, uiStyle = 'nta') {
      if (!setObj || !setObj.questions.length) return;
      if (state.session.timerId) clearInterval(state.session.timerId);
      const s = state.session;
      s.mode = mode;
      s.uiStyle = uiStyle;
      s.title = setObj.title;
      s.questions = setObj.questions;
      s.idx = 0;
      s.responses = {};
      s.statuses = {};
      s.revealed = {};
      s.qTimes = {};
      s.questions.forEach((q, i) => { s.statuses[q.id] = i === 0 ? 'not_answered' : 'not_visited'; });
      s.totalSeconds = (setObj.mins || 30) * 60;
      s.seconds = mode === 'practice' ? 0 : s.totalSeconds;

      s.timerId = setInterval(() => {
        const curQ = s.questions[s.idx];
        if (curQ) s.qTimes[curQ.id] = (s.qTimes[curQ.id] || 0) + 1;
        if (s.mode === 'practice') {
          s.seconds++;
          if (s.uiStyle === 'nta') $('cbtTimerText').textContent = fmtMMSS(s.seconds);
          else $('pracTimerText').textContent = fmtMMSS(s.seconds);
        } else {
          s.seconds = Math.max(0, s.seconds - 1);
          if (s.uiStyle === 'nta') $('cbtTimerText').textContent = fmtMMSS(s.seconds);
          else $('pracTimerText').textContent = fmtMMSS(s.seconds);
          if (s.seconds <= 0) finishSession();
        }
      }, 1000);

      if (uiStyle === 'nta') {
        $('cbtTopBannerTitle').textContent = `${s.title.toUpperCase()} (${mode === 'practice' ? 'PRACTICE' : 'CBT TEST'})`;
        $('cbtSectionPill').textContent = s.title;
        $('cbtTimerText').textContent = fmtMMSS(s.seconds);
        $('cbtSaveNextBtn').textContent = mode === 'practice' ? 'Check Answer / Next' : 'Save & Next';
        showView('cbt');
        renderCBTQuestion();
      } else {
        $('pracTimerText').textContent = fmtMMSS(s.seconds);
        $('pracCheckBtn').textContent = mode === 'practice' ? 'Check Answer' : 'Save & Next';
        showView('practice');
        renderPracticeQuestion();
      }
    }

    // ==================== CLASSIC NTA CBT RENDERER ====================
    const IMG_INDEX = new Map();
    BANK.forEach(ch => ch.questions.forEach(q => { if (q.id && q.dataUrl) IMG_INDEX.set(q.id, q.dataUrl); }));
    function getImgSrc(q) {
      if (!q) return '';
      if (q.dataUrl && q.dataUrl.startsWith('data:image/')) return q.dataUrl;
      if (q.imgData && q.imgData.startsWith('data:image/')) return q.imgData;
      return IMG_INDEX.get(q.id) || '';
    }

    function renderQuestionContent(q, typedEl, imgBoxEl, imgEl, scanBtnEl, isDarkUi) {
      if (typedEl) typedEl.classList.add('hidden');
      if (scanBtnEl) scanBtnEl.classList.add('hidden');
      const src = getImgSrc(q);
      imgEl.src = src;
      imgEl.style.display = src ? 'block' : 'none';
      imgEl.style.width = '100%';
      imgEl.style.height = 'auto';
      if (imgBoxEl) {
        imgBoxEl.classList.remove('hidden');
        imgBoxEl.style.display = 'block';
      }
      imgBoxEl.classList.remove('hidden');
      if (isDarkUi) {
        imgEl.classList.toggle('pdf-dark-invert', state.session.invertPractice && !q.isDark);
        imgBoxEl.className = 'rounded-2xl border border-slate-800 bg-[#0b101d] p-2.5 overflow-auto w-full';
      } else {
        const darkNta = Boolean(state.session.ntaQDark);
        imgEl.className = darkNta && !q.isDark
          ? 'mx-auto h-auto pdf-dark-invert cursor-zoom-in'
          : 'mx-auto h-auto pdf-light-crisp cursor-zoom-in';
        imgBoxEl.className = darkNta
          ? 'rounded-xl border border-slate-800 bg-[#0b101d] p-2 overflow-auto shadow-sm w-full'
          : 'rounded-xl border border-slate-200 bg-white p-2 overflow-auto shadow-sm w-full';
      }
    }

    function renderCBTQuestion() {
      const s = state.session;
      const q = s.questions[s.idx];
      if (!q) return;
      if (s.statuses[q.id] === 'not_visited') s.statuses[q.id] = 'not_answered';

      $('cbtQNum').textContent = s.idx + 1;
      $('cbtQTotal').textContent = s.questions.length;
      $('cbtQTypeText').textContent = q.multiCorrect ? 'Multi-Correct MCQ' : (q.type === 'MCQ' ? 'Single Correct' : 'Numerical');
      $('cbtScrollArea').scrollTop = 0;

      renderQuestionContent(q, $('cbtTypedText'), $('cbtImgBox'), $('cbtQuestionImg'), $('cbtShowScanBtn'), false);

      const bkBtn = $('cbtBkClassicBtn');
      const saved = isBk(q.id);
      bkBtn.textContent = saved ? '★ Saved' : '☆ Save';
      bkBtn.className = saved
        ? 'px-2 py-1 rounded border border-amber-400 bg-amber-50 text-amber-700 text-[11px] font-bold'
        : 'px-2 py-1 rounded border border-slate-300 text-slate-600 hover:bg-slate-100 text-[11px] font-semibold';
      bkBtn.onclick = () => { toggleBk(q); renderCBTQuestion(); };

      const resp = s.responses[q.id] || '';
      const isPrac = s.mode === 'practice';
      const rev = isPrac && Boolean(s.revealed[q.id]);
      const key = (q.answerKey || '').trim();
      const keyN = key.toUpperCase();

      if (q.type === 'MCQ') {
        $('cbtMcqOptions').classList.remove('hidden');
        $('cbtNumWrap').classList.add('hidden');
        const opts = q.optStyle === '1234' ? ['1', '2', '3', '4'] : ['A', 'B', 'C', 'D'];
        $('cbtMcqOptions').innerHTML = opts.map(o => {
          const sel = resp === o;
          const ok = rev && keyN === o;
          const bad = rev && sel && keyN && keyN !== o && keyN !== 'BONUS';
          let cls = sel ? 'border-[#1b7ec2] bg-sky-50 text-slate-900 font-bold' : 'border-slate-200 bg-white text-slate-800 hover:bg-slate-50';
          if (ok) cls = 'border-emerald-500 bg-emerald-50 text-emerald-900 font-bold';
          else if (bad) cls = 'border-rose-500 bg-rose-50 text-rose-900 font-bold';
          const optTxt = (q.qOptions && q.qOptions[o]) ? `${o}. ${q.qOptions[o]}` : `Option (${o})`;
          return `
            <button type="button" data-opt="${o}" class="cbt-radio-opt w-full flex items-center gap-3 px-3.5 py-3 rounded-xl border text-left transition ${cls}">
              <span class="w-5 h-5 rounded-full border-2 flex items-center justify-center shrink-0 ${sel ? 'border-[#1b7ec2]' : 'border-slate-400'}">
                ${sel ? '<span class="w-2.5 h-2.5 rounded-full bg-[#1b7ec2]"></span>' : ''}
              </span>
              <span class="text-sm font-medium leading-snug">${optTxt}</span>
            </button>
          `;
        }).join('');
        $('cbtMcqOptions').querySelectorAll('.cbt-radio-opt').forEach(b => {
          b.onclick = () => {
            s.responses[q.id] = b.dataset.opt;
            s.statuses[q.id] = 'answered';
            if (isPrac) s.revealed[q.id] = true;
            renderCBTQuestion();
          };
        });
      } else {
        $('cbtMcqOptions').classList.add('hidden');
        $('cbtNumWrap').classList.remove('hidden');
        $('cbtNumInput').value = resp;
        $('cbtNumInput').oninput = (e) => {
          const v = e.target.value.trim();
          if (v) s.responses[q.id] = v; else delete s.responses[q.id];
        };
      }

      const fb = $('cbtPracticeFeedback');
      if (rev) {
        fb.classList.remove('hidden');
        const uN = resp.trim().toUpperCase();
        const isOk = keyN === 'BONUS' || (keyN && uN === keyN);
        const vid = q.videoId || '', vs = q.videoStart || 0, ve = q.videoEnd || (vs + 180);
        const vBtn = vid ? `<button type="button" id="cbtShowVidBtn" class="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 text-white text-xs font-bold"><i data-lucide="youtube" class="w-4 h-4"></i><span>Show Video Solution</span></button><div id="cbtVidSlot"></div>` : '';
        if (!key) {
          fb.className = 'rounded-xl border border-amber-300 bg-amber-50 p-3.5 text-amber-900 text-xs space-y-1';
          fb.innerHTML = `<div class="font-bold">No Official Key in PDF</div>${vBtn}`;
        } else if (isOk) {
          fb.className = 'rounded-xl border border-emerald-400 bg-emerald-50 p-3.5 text-emerald-900 text-xs space-y-1';
          fb.innerHTML = `<div class="text-sm font-extrabold text-emerald-700">Correct!</div><div>Official Answer: <span class="font-mono font-bold">${key}</span></div>${vBtn}`;
        } else {
          fb.className = 'rounded-xl border border-rose-400 bg-rose-50 p-3.5 text-rose-900 text-xs space-y-1';
          fb.innerHTML = `<div class="text-sm font-extrabold text-rose-700">Incorrect</div><div>Your: <span class="font-mono font-bold">${resp || '—'}</span> | Official: <span class="font-mono font-bold text-emerald-700">${key}</span></div>${vBtn}`;
        }
        const svb = $('cbtShowVidBtn');
        if (svb && vid) {
          svb.onclick = () => {
            const slot = $('cbtVidSlot');
            if (slot.innerHTML) { slot.innerHTML = ''; svb.querySelector('span').textContent = 'Show Video Solution'; }
            else { slot.innerHTML = buildVideoCard(vid, vs, ve); svb.querySelector('span').textContent = 'Hide Video Solution'; if (window.lucide) lucide.createIcons(); }
          };
        }
      } else {
        fb.classList.add('hidden');
        fb.innerHTML = '';
      }
      renderCBTPalette();
      if (window.lucide) lucide.createIcons();
    }

    function renderCBTPalette() {
      const s = state.session;
      let cA = 0, cNA = 0, cU = 0, cM = 0;
      s.questions.forEach(q => {
        const st = s.statuses[q.id] || 'not_visited';
        if (st === 'answered') cA++;
        else if (st === 'not_answered') cNA++;
        else if (st === 'marked' || st === 'ans_marked') cM++;
        else cU++;
      });
      $('palCntAns').textContent = cA;
      $('palCntNotAns').textContent = cNA;
      $('palCntUnvis').textContent = cU;
      $('palCntMark').textContent = cM;

      $('cbtPaletteGrid').innerHTML = s.questions.map((q, i) => {
        const st = s.statuses[q.id] || 'not_visited';
        const cls = st === 'answered' ? 'nta-answered' : st === 'not_answered' ? 'nta-not-answered' : st === 'marked' ? 'nta-marked' : st === 'ans_marked' ? 'nta-ans-marked' : 'nta-not-visited';
        const cur = i === s.idx ? 'ring-2 ring-amber-500 ring-offset-1' : '';
        return `<button type="button" data-i="${i}" class="pal-q-btn h-10 font-mono text-xs font-bold flex items-center justify-center ${cls} ${cur}">${i + 1}</button>`;
      }).join('');
      $('cbtPaletteGrid').querySelectorAll('.pal-q-btn').forEach(b => {
        b.onclick = () => { s.idx = parseInt(b.dataset.i, 10); $('cbtPaletteDrawer').classList.add('hidden'); renderCBTQuestion(); };
      });
    }

    // ==================== DARK PRACTICE MODE RENDERER ====================
    function renderPracticeQuestion() {
      const s = state.session;
      const q = s.questions[s.idx];
      if (!q) return;

      $('pracQNum').textContent = s.idx + 1;
      $('pracQTotal').textContent = s.questions.length;
      $('pracQSub').textContent = q.subject || s.title;
      $('pracTypeLbl').textContent = q.multiCorrect ? 'Multi-Correct (tap multiple)' : (q.type === 'MCQ' ? 'Single correct' : 'Numerical / Subjective');

      renderQuestionContent(q, $('pracTypedText'), $('pracImgBox'), $('pracQuestionImg'), $('pracShowScanBtn'), true);
      $('pracScrollBody').scrollTop = 0;

      const bk = $('pracBkBtn');
      const saved = isBk(q.id);
      bk.className = `py-1.5 rounded-xl border text-[11px] font-bold flex items-center justify-center gap-1 ${saved ? 'bg-amber-500/25 border-amber-400 text-amber-300' : 'bg-[#11182c] border-slate-800 text-slate-300'}`;
      bk.onclick = () => { toggleBk(q); renderPracticeQuestion(); };

      const resp = s.responses[q.id] || '';
      const rev = s.mode === 'practice' && Boolean(s.revealed[q.id]);
      const key = (q.answerKey || '').trim();
      const keyN = key.toUpperCase();

      if (q.type === 'MCQ') {
        $('pracMcqOptions').classList.remove('hidden');
        $('pracNumWrap').classList.add('hidden');
        const opts = q.optStyle === '1234' ? ['1', '2', '3', '4'] : ['A', 'B', 'C', 'D'];
        $('pracMcqOptions').innerHTML = opts.map(o => {
          const sel = resp === o;
          const ok = rev && keyN === o;
          const bad = rev && sel && keyN && keyN !== o && keyN !== 'BONUS';
          let cls = sel ? 'bg-indigo-500/20 border-indigo-400 text-white' : 'bg-[#0e1528] border-slate-800 text-slate-200 hover:border-slate-600';
          let bCls = sel ? 'bg-indigo-500 text-white' : 'bg-slate-800 text-slate-300';
          if (ok) { cls = 'bg-emerald-500/20 border-emerald-400 text-emerald-100'; bCls = 'bg-emerald-500 text-white'; }
          else if (bad) { cls = 'bg-rose-500/20 border-rose-400 text-rose-100'; bCls = 'bg-rose-500 text-white'; }
          return `<button type="button" data-opt="${o}" class="prac-opt-btn w-full flex items-center gap-3 px-4 py-3 rounded-2xl border text-left transition ${cls}"><span class="w-7 h-7 rounded-full font-mono text-xs font-bold flex items-center justify-center ${bCls}">${o}</span><span class="text-sm font-medium leading-snug">${(q.qOptions && q.qOptions[o]) ? q.qOptions[o] : `Option (${o})`}</span></button>`;
        }).join('');
        $('pracMcqOptions').querySelectorAll('.prac-opt-btn').forEach(b => {
          b.onclick = () => { s.responses[q.id] = b.dataset.opt; s.statuses[q.id] = 'answered'; if (s.mode === 'practice') s.revealed[q.id] = true; renderPracticeQuestion(); };
        });
      } else {
        $('pracMcqOptions').classList.add('hidden');
        $('pracNumWrap').classList.remove('hidden');
        $('pracNumInput').value = resp;
        $('pracNumInput').oninput = (e) => {
          const v = e.target.value.trim();
          if (v) s.responses[q.id] = v; else delete s.responses[q.id];
        };
      }

      const fb = $('pracFeedbackBox');
      if (rev) {
        fb.classList.remove('hidden');
        const uN = resp.trim().toUpperCase();
        const isOk = keyN === 'BONUS' || (keyN && uN === keyN);
        const vid = q.videoId || '';
        const vs = q.videoStart || 0, ve = q.videoEnd || (vs + 180);
        const vidBtn = vid ? `<button type="button" id="pracShowVidBtn" class="mt-2 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"><i data-lucide="youtube" class="w-4 h-4"></i><span>Show Video Solution</span></button><div id="pracVidSlot"></div>` : '';
        if (!key) {
          fb.className = 'rounded-2xl border border-amber-500/35 bg-amber-500/10 p-4 space-y-1';
          fb.innerHTML = `<div class="text-xs font-bold text-amber-300">No Official Key in PDF</div>${vidBtn}`;
        } else if (!resp) {
          fb.className = 'rounded-2xl border border-indigo-500/35 bg-indigo-500/10 p-4 space-y-1';
          fb.innerHTML = `<div class="text-xs font-bold text-indigo-300">Official Answer: <span class="font-mono text-white">${key}</span></div>${vidBtn}`;
        } else if (isOk) {
          fb.className = 'rounded-2xl border border-emerald-500/40 bg-emerald-500/15 p-4 space-y-1';
          fb.innerHTML = `<div class="text-sm font-extrabold text-emerald-300">Correct!</div><div class="text-xs text-slate-200">Official Answer: <span class="font-mono font-bold text-white">${key}</span></div>${vidBtn}`;
        } else {
          fb.className = 'rounded-2xl border border-rose-500/40 bg-rose-500/15 p-4 space-y-1';
          fb.innerHTML = `<div class="text-sm font-extrabold text-rose-300">Incorrect</div><div class="text-xs text-slate-200">Your: <span class="font-mono font-bold text-rose-200">${resp}</span> | Official: <span class="font-mono font-bold text-emerald-300">${key}</span></div>${vidBtn}`;
        }
        const svb = $('pracShowVidBtn');
        if (svb && vid) {
          svb.onclick = () => {
            const slot = $('pracVidSlot');
            if (slot.innerHTML) { slot.innerHTML = ''; svb.querySelector('span').textContent = 'Show Video Solution'; }
            else {
              slot.innerHTML = buildVideoCard(vid, vs, ve);
              svb.querySelector('span').textContent = 'Hide Video Solution';
              if (window.lucide) lucide.createIcons();
            }
          };
        }
      } else {
        fb.classList.add('hidden');
        fb.innerHTML = '';
      }
      if (window.lucide) lucide.createIcons();
    }

    function buildVideoCard(vid, vs, ve) {
      const uid = 'yt_' + Math.random().toString(36).slice(2, 8);
      const isHttp = location.protocol.startsWith('http');
      const renderInner = (s, e) => {
        const player = isHttp
          ? `<div class="aspect-video w-full bg-black"><iframe class="w-full h-full" referrerpolicy="strict-origin-when-cross-origin" src="https://www.youtube.com/embed/${vid}?start=${s}&end=${e}&autoplay=1&rel=0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>`
          : `<a href="https://youtu.be/${vid}?t=${s}" target="_blank" rel="noopener noreferrer" class="relative block aspect-video w-full bg-slate-950 overflow-hidden"><img src="https://i.ytimg.com/vi/${vid}/hqdefault.jpg" class="w-full h-full object-cover opacity-80" /><div class="absolute inset-0 bg-black/45 flex flex-col items-center justify-center gap-2"><div class="w-12 h-12 rounded-full bg-rose-600 text-white flex items-center justify-center"><i data-lucide="play" class="w-5 h-5 ml-0.5"></i></div><span class="px-3 py-1 rounded-full bg-black/80 text-xs font-bold text-white">Watch at ${fmtMMSS(s)} &rarr;</span></div></a>`;
        return `<div class="px-2.5 py-1.5 bg-slate-900 flex flex-wrap items-center justify-between gap-1.5 text-[11px]"><span class="font-bold text-rose-300">Clip ${fmtMMSS(s)}–${fmtMMSS(e)}</span><div class="flex items-center gap-1"><button type="button" onclick="window._nudgeYt('${uid}','${vid}',${Math.max(0, s-30)},${Math.max(60, e-30)})" class="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 font-mono">-30s</button><button type="button" onclick="window._nudgeYt('${uid}','${vid}',${Math.max(0, s-10)},${Math.max(60, e-10)})" class="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 font-mono">-10s</button><button type="button" onclick="window._nudgeYt('${uid}','${vid}',${s+10},${e+10})" class="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 font-mono">+10s</button><button type="button" onclick="window._nudgeYt('${uid}','${vid}',${s+30},${e+30})" class="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 font-mono">+30s</button><a href="https://youtu.be/${vid}?t=${s}" target="_blank" rel="noopener noreferrer" class="px-2 py-0.5 rounded bg-rose-600 text-white font-bold">YT&nearr;</a></div></div>${player}`;
      };
      window._nudgeYt = (id, v, ns, ne) => {
        const box = document.getElementById(id);
        if (!box) return;
        const p = location.protocol.startsWith('http')
          ? `<div class="aspect-video w-full bg-black"><iframe class="w-full h-full" referrerpolicy="strict-origin-when-cross-origin" src="https://www.youtube.com/embed/${v}?start=${ns}&end=${ne}&autoplay=1&rel=0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>`
          : `<a href="https://youtu.be/${v}?t=${ns}" target="_blank" rel="noopener noreferrer" class="relative block aspect-video w-full bg-slate-950 overflow-hidden"><img src="https://i.ytimg.com/vi/${v}/hqdefault.jpg" class="w-full h-full object-cover opacity-80" /><div class="absolute inset-0 bg-black/45 flex flex-col items-center justify-center gap-2"><div class="w-12 h-12 rounded-full bg-rose-600 text-white flex items-center justify-center"><i data-lucide="play" class="w-5 h-5 ml-0.5"></i></div><span class="px-3 py-1 rounded-full bg-black/80 text-xs font-bold text-white">Watch at ${fmtMMSS(ns)} &rarr;</span></div></a>`;
        box.innerHTML = `<div class="px-2.5 py-1.5 bg-slate-900 flex flex-wrap items-center justify-between gap-1.5 text-[11px]"><span class="font-bold text-rose-300">Clip ${fmtMMSS(ns)}–${fmtMMSS(ne)}</span><div class="flex items-center gap-1"><button type="button" onclick="window._nudgeYt('${id}','${v}',${Math.max(0, ns-30)},${Math.max(60, ne-30)})" class="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 font-mono">-30s</button><button type="button" onclick="window._nudgeYt('${id}','${v}',${Math.max(0, ns-10)},${Math.max(60, ne-10)})" class="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 font-mono">-10s</button><button type="button" onclick="window._nudgeYt('${id}','${v}',${ns+10},${ne+10})" class="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 font-mono">+10s</button><button type="button" onclick="window._nudgeYt('${id}','${v}',${ns+30},${ne+30})" class="px-1.5 py-0.5 rounded bg-slate-800 text-slate-200 font-mono">+30s</button><a href="https://youtu.be/${v}?t=${ns}" target="_blank" rel="noopener noreferrer" class="px-2 py-0.5 rounded bg-rose-600 text-white font-bold">YT&nearr;</a></div></div>${p}`;
        if (window.lucide) lucide.createIcons();
      };
      return `<div id="${uid}" class="mt-2 rounded-xl overflow-hidden border border-rose-500/35 bg-[#070a14]">${renderInner(vs, ve)}</div>`;
    }

    // ==================== FINISH & RANKVORTEX ANALYSIS ====================
    function finishSession() {
      const s = state.session;
      if (s.timerId) clearInterval(s.timerId);
      const elapsed = s.mode === 'practice' ? s.seconds : Math.max(0, s.totalSeconds - s.seconds);
      let sCor = 0, sWrg = 0;
      s.questions.forEach(q => {
        const u = (s.responses[q.id] || '').trim().toUpperCase();
        const k = (q.answerKey || '').trim().toUpperCase();
        if (k === 'BONUS' || k === 'DROPPED') sCor++;
        else if (u && k) { if (u === k) sCor++; else sWrg++; }
      });
      const snap = {
        id: 'att_' + Date.now(),
        title: s.title,
        mode: s.mode,
        savedAt: new Date().toLocaleString(),
        elapsed,
        score: sCor * 4 - sWrg,
        maxScore: s.questions.length * 4,
        accuracy: (sCor + sWrg) ? Math.round((sCor / (sCor + sWrg)) * 100) : 0,
        questions: s.questions,
        responses: { ...s.responses },
        qTimes: { ...s.qTimes }
      };
      state.activeAttempt = snap;
      saveAttempt(snap);
      state.analysisSub = 'overview';
      state.solIdx = 0;
      showView('analysis');
      if (window.confetti) confetti({ particleCount: 60, spread: 60, origin: { y: 0.65 } });
    }

    function setAnalysisSub(sub) {
      state.analysisSub = sub;
      document.querySelectorAll('.an-sub').forEach(p => p.classList.add('hidden'));
      $(`anPanel-${sub}`).classList.remove('hidden');
      const titles = { overview: 'Overview', performance: 'Performance Analysis', attempt: 'Attempt Analysis', solution: 'View Solution' };
      $('anHeading').textContent = titles[sub] || 'Overview';
      document.querySelectorAll('.an-pill-btn').forEach(b => {
        const act = b.dataset.asub === sub;
        b.className = `an-pill-btn px-3.5 py-2 rounded-full text-xs whitespace-nowrap transition ${act ? 'font-bold bg-[#172038] border border-indigo-400/50 text-white' : 'font-semibold bg-[#0e1426] border border-slate-800 text-slate-400'}`;
      });
    }

    function renderAnalysis() {
      const all = getAttempts();
      const sel = $('savedAttemptsSel');
      sel.innerHTML = all.length ? all.map(a => `<option value="${a.id}">${a.title.slice(0, 20)} (${a.savedAt})</option>`).join('') : `<option value="">No saved attempts</option>`;
      const snap = state.activeAttempt || all[0];
      if (!snap) { $('anMetaLine').textContent = 'Finish a Practice or CBT test to view analysis.'; return; }
      sel.value = snap.id;
      $('anMetaLine').textContent = `${snap.title} • ${snap.mode.toUpperCase()} • ${snap.savedAt}`;

      let cor = 0, wrg = 0, skp = 0, pos = 0, neg = 0;
      const byTopic = {};
      const evals = snap.questions.map((q, i) => {
        const u = (snap.responses[q.id] || '').trim().toUpperCase();
        const k = (q.answerKey || '').trim().toUpperCase();
        const tp = q.chapter || q.subject || 'Physics';
        if (!byTopic[tp]) byTopic[tp] = { score: 0, cor: 0, wrg: 0, skp: 0, tot: 0 };
        byTopic[tp].tot++;
        let out = 'skipped', mks = 0;
        if (k === 'BONUS' || k === 'DROPPED') { cor++; pos += 4; mks = 4; out = 'correct'; byTopic[tp].cor++; byTopic[tp].score += 4; }
        else if (!u) { skp++; out = 'skipped'; byTopic[tp].skp++; }
        else if (!k) { out = 'unkeyed'; }
        else if (u === k) { cor++; pos += 4; mks = 4; out = 'correct'; byTopic[tp].cor++; byTopic[tp].score += 4; }
        else { wrg++; neg += 1; mks = -1; out = 'wrong'; byTopic[tp].wrg++; byTopic[tp].score -= 1; }
        return { q, i, u, k, out, mks, t: snap.qTimes[q.id] || 0 };
      });

      const totQ = snap.questions.length;
      const att = cor + wrg;
      const net = pos - neg;
      $('anScoreBig').textContent = net;
      $('anScoreMax').textContent = `/ ${totQ * 4}`;
      $('anAttempted').textContent = `${att}/${totQ}`;
      $('anAccuracy').textContent = att ? `${Math.round((cor / att) * 100)}%` : '—';
      $('anPosScore').textContent = `+${pos}`;
      $('anNegScore').textContent = `-${neg}`;
      $('anTimeTaken').textContent = fmtHuman(snap.elapsed);
      $('perfCardPos').textContent = `+${pos}`;
      $('perfCardNeg').textContent = `-${neg}`;
      $('perfCardPct').textContent = `${totQ ? Math.max(0, Math.round((net / (totQ * 4)) * 100)) : 0}%`;
      const avgS = att ? Math.round(snap.elapsed / att) : (totQ ? Math.round(snap.elapsed / totQ) : 0);
      $('perfCardPace').textContent = `${avgS}s/Q`;

      $('anPerfTbody').innerHTML = Object.entries(byTopic).map(([tp, st]) => `
        <tr><td class="py-2.5 px-3 font-sans font-semibold text-white">${tp}</td><td class="py-2.5 px-3 text-sky-300">${st.score}/${st.tot * 4}</td><td class="py-2.5 px-3 text-emerald-400">${st.cor}</td><td class="py-2.5 px-3 text-rose-400">${st.wrg}</td><td class="py-2.5 px-3 text-slate-400">${st.skp}</td></tr>
      `).join('');

      $('anAttTbody').innerHTML = evals.map(e => `
        <tr class="hover:bg-slate-900/50 cursor-pointer att-row" data-si="${e.i}">
          <td class="py-2.5 px-3 font-mono font-bold text-white">${e.i + 1}</td>
          <td class="py-2.5 px-3 text-slate-300 truncate max-w-[130px]">${e.q.chapter || e.q.subject}</td>
          <td class="py-2.5 px-3 font-bold ${e.out === 'correct' ? 'text-emerald-400' : e.out === 'wrong' ? 'text-rose-400' : 'text-slate-400'}">${e.out}</td>
          <td class="py-2.5 px-3 font-mono text-amber-300">${fmtHuman(e.t)}</td>
          <td class="py-2.5 px-3 font-mono font-bold text-white">${e.mks > 0 ? '+' + e.mks : e.mks}</td>
        </tr>
      `).join('');
      $('anAttTbody').querySelectorAll('.att-row').forEach(tr => {
        tr.onclick = () => { state.solIdx = parseInt(tr.dataset.si, 10); setAnalysisSub('solution'); renderSolCard(evals); };
      });

      const chapPrev = all.filter(a => a.title === snap.title);
      $('chapterHistoryList').innerHTML = chapPrev.map((a, idx) => `
        <button type="button" data-aid="${a.id}" class="chap-hist-item w-full flex items-center justify-between px-3 py-2 rounded-xl border text-left transition ${a.id === snap.id ? 'bg-indigo-600/20 border-indigo-400/60 text-white' : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:bg-slate-800'}">
          <span class="font-semibold">Attempt #${chapPrev.length - idx} <span class="text-[10px] text-slate-400">(${a.mode.toUpperCase()} • ${a.savedAt})</span></span>
          <span class="font-mono font-bold text-emerald-400">${a.score ?? 0}/${a.maxScore ?? (a.questions.length * 4)} (${a.accuracy ?? 0}%)</span>
        </button>
      `).join('');
      $('chapterHistoryList').querySelectorAll('.chap-hist-item').forEach(b => {
        b.onclick = () => {
          const f = all.find(x => x.id === b.dataset.aid);
          if (f) { state.activeAttempt = f; state.solIdx = 0; renderAnalysis(); }
        };
      });
      renderSolCard(evals);
      setAnalysisSub(state.analysisSub);
    }

    function renderSolCard(evals) {
      if (!evals.length) return;
      if (state.solIdx >= evals.length) state.solIdx = 0;
      $('anSolPalette').innerHTML = evals.map((e, i) => {
        const cls = e.out === 'correct' ? 'bg-emerald-600/25 border-emerald-500/50 text-emerald-300' : e.out === 'wrong' ? 'bg-rose-600/25 border-rose-500/50 text-rose-300' : 'bg-slate-800 border-slate-700 text-slate-300';
        return `<button data-si="${i}" class="sol-q-btn w-9 h-9 rounded-lg border font-mono text-xs font-bold ${cls} ${i === state.solIdx ? 'ring-2 ring-sky-400' : ''}">${i + 1}</button>`;
      }).join('');
      $('anSolPalette').querySelectorAll('.sol-q-btn').forEach(b => {
        b.onclick = () => { state.solIdx = parseInt(b.dataset.si, 10); renderSolCard(evals); };
      });

      const e = evals[state.solIdx];
      const saved = isBk(e.q.id);
      const vid = e.q.videoId || '', vs = e.q.videoStart || 0, ve = e.q.videoEnd || (vs + 180);
      $('anSolCard').innerHTML = `
        <div class="bg-[#0e1426] border border-slate-800 rounded-2xl p-4 space-y-3">
          <div class="flex items-center justify-between gap-2">
            <span class="font-mono text-xs font-bold text-indigo-300">Q.${e.i + 1} • ${e.q.chapter || e.q.subject}</span>
            <button id="solBkBtn" type="button" class="px-2.5 py-1 rounded-lg border text-xs font-bold ${saved ? 'bg-amber-500/20 border-amber-400 text-amber-300' : 'bg-slate-800 border-slate-700 text-slate-300'}">${saved ? '★ Saved' : '☆ Bookmark'}</button>
          </div>
          <div class="rounded-xl bg-[#090d18] border border-slate-800 p-2 overflow-auto">
            <img src="${getImgSrc(e.q)}" class="mx-auto max-h-72 rounded ${e.q.isDark ? '' : 'pdf-dark-invert'}" />
          </div>
          <div class="grid grid-cols-3 gap-2 bg-slate-950/70 p-2.5 rounded-xl text-center text-xs">
            <div><div class="text-[10px] text-slate-400">Time</div><div class="font-mono font-bold text-amber-300">${fmtHuman(e.t)}</div></div>
            <div><div class="text-[10px] text-slate-400">Your Ans</div><div class="font-mono font-bold ${e.out === 'correct' ? 'text-emerald-400' : e.out === 'wrong' ? 'text-rose-400' : 'text-slate-400'}">${e.u || '—'}</div></div>
            <div><div class="text-[10px] text-slate-400">Official Key</div><div class="font-mono font-bold text-sky-400">${e.k || '—'}</div></div>
          </div>
          ${vid ? `<button id="solVidBtn" type="button" class="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-bold"><i data-lucide="youtube" class="w-4 h-4"></i><span>Show Video Solution</span></button><div id="solVidSlot"></div>` : ''}
        </div>
      `;
      $('solBkBtn').onclick = () => { toggleBk(e.q); renderSolCard(evals); };
      const svb = $('solVidBtn');
      if (svb && vid) {
        svb.onclick = () => {
          const slot = $('solVidSlot');
          if (slot.innerHTML) { slot.innerHTML = ''; svb.querySelector('span').textContent = 'Show Video Solution'; }
          else { slot.innerHTML = buildVideoCard(vid, vs, ve); svb.querySelector('span').textContent = 'Hide Video Solution'; if (window.lucide) lucide.createIcons(); }
        };
      }
      if (window.lucide) lucide.createIcons();
    }

    // ==================== BOOKMARKS ====================
    function renderBookmarks() {
      const list = getBks();
      $('bkCountSub').textContent = `${list.length} saved question${list.length === 1 ? '' : 's'}`;
      $('bkListGrid').innerHTML = list.length === 0
        ? `<div class="p-10 text-center bg-[#0d1324] border border-slate-800 rounded-2xl text-sm text-slate-400">No bookmarks yet. Tap Save/Bookmark on any question.</div>`
        : list.map((q, i) => `
          <div class="bg-[#0d1324] border border-slate-800 rounded-2xl p-3.5 space-y-2.5">
            <div class="flex items-center justify-between"><span class="text-xs font-bold text-amber-300">#${i + 1} • ${q.chapter || q.subject}</span><button data-id="${q.id}" class="rm-bk px-2.5 py-1 rounded-lg bg-rose-500/20 text-rose-300 text-xs font-bold">Remove</button></div>
            <img src="${getImgSrc(q)}" class="mx-auto max-h-56 rounded-lg ${q.isDark ? '' : 'pdf-dark-invert'}" />
          </div>
        `).join('');
      $('bkListGrid').querySelectorAll('.rm-bk').forEach(b => {
        b.onclick = () => { setBks(getBks().filter(x => x.id !== b.dataset.id)); renderBookmarks(); };
      });
    }

    // ==================== ZOOM LIGHTBOX ====================
    let zm = 125;
    function openZoom(src, inverted) {
      if (!src) return;
      zm = 125;
      $('zmImg').src = src;
      $('zmImg').style.width = '125%';
      $('zmImg').className = inverted ? 'h-auto rounded-lg pdf-dark-invert' : 'h-auto rounded-lg bg-white p-2';
      $('zmPct').textContent = '125%';
      $('zoomModal').classList.remove('hidden');
    }

    // ==================== BOOTSTRAP ====================
    window.addEventListener('DOMContentLoaded', () => {
      setBks(getBks());
      renderFolders();
      showView('folders');

      $('logoHomeBtn').onclick = () => showView('folders');
      $('searchInput').oninput = (e) => { state.search = e.target.value; renderFolders(); };
      document.querySelectorAll('.seg-btn').forEach(b => {
        b.onclick = () => {
          state.segment = b.dataset.seg;
          document.querySelectorAll('.seg-btn').forEach(x => {
            const act = x.dataset.seg === state.segment;
            x.className = `seg-btn px-3.5 py-2 rounded-xl text-xs whitespace-nowrap ${act ? 'font-bold bg-indigo-600 text-white shadow' : 'font-semibold bg-[#0e1426] text-slate-300 border border-slate-800'}`;
          });
          renderFolders();
        };
      });
      document.querySelectorAll('.bnav-btn').forEach(b => { b.onclick = () => showView(b.dataset.view); });

      // Instructions
      $('instBackBtn').onclick = () => showView('folders');
      $('uiModalCloseBtn').onclick = () => $('uiChoiceModal').classList.add('hidden');
      $('pickNtaUiBtn').onclick = () => {
        $('uiChoiceModal').classList.add('hidden');
        if (state.pendingMode === 'cbt') openInstructions(state.pendingSet, 'nta');
        else startSession(state.pendingSet, 'practice', 'nta');
      };
      $('pickDarkUiBtn').onclick = () => {
        $('uiChoiceModal').classList.add('hidden');
        if (state.pendingMode === 'cbt') openInstructions(state.pendingSet, 'dark');
        else startSession(state.pendingSet, 'practice', 'dark');
      };
      $('instBeginBtn').onclick = () => {
        if (!$('instAgreeCheck').checked) { toast('Please tick the agreement checkbox first.', 'warn'); return; }
        startSession(state.pendingSet, 'cbt', state.pendingUi || 'nta');
      };

      // CBT Actions
      $('cbtSaveNextBtn').onclick = () => {
        const s = state.session, q = s.questions[s.idx];
        if (s.mode === 'practice' && !s.revealed[q.id]) {
          s.revealed[q.id] = true;
          if (s.responses[q.id]) s.statuses[q.id] = 'answered';
          renderCBTQuestion();
          return;
        }
        s.statuses[q.id] = s.responses[q.id] ? 'answered' : 'not_answered';
        if (s.idx < s.questions.length - 1) s.idx++;
        renderCBTQuestion();
      };
      $('cbtMarkNextBtn').onclick = () => {
        const s = state.session, q = s.questions[s.idx];
        s.statuses[q.id] = s.responses[q.id] ? 'ans_marked' : 'marked';
        if (s.idx < s.questions.length - 1) s.idx++;
        renderCBTQuestion();
      };
      $('cbtClearBtn').onclick = () => {
        const s = state.session, q = s.questions[s.idx];
        delete s.responses[q.id];
        s.statuses[q.id] = 'not_answered';
        renderCBTQuestion();
      };
      $('cbtSubmitBtn').onclick = finishSession;
      $('cbtPaletteSubmitBtn').onclick = () => { $('cbtPaletteDrawer').classList.add('hidden'); finishSession(); };
      $('cbtPaletteOpenBtn').onclick = () => $('cbtPaletteDrawer').classList.remove('hidden');
      $('cbtPaletteCloseBtn').onclick = () => $('cbtPaletteDrawer').classList.add('hidden');
      $('cbtUiThemeBtn').onclick = () => {
        state.session.ntaUiDark = !state.session.ntaUiDark;
        $('view-cbt').classList.toggle('nta-dark-mode', state.session.ntaUiDark);
        $('cbtUiThemeLbl').textContent = state.session.ntaUiDark ? 'UI: Dark' : 'UI: Bright';
      };
      $('cbtQThemeBtn').onclick = () => {
        state.session.ntaQDark = !state.session.ntaQDark;
        $('cbtQThemeLbl').textContent = state.session.ntaQDark ? 'Q: Dark' : 'Q: Bright';
        renderCBTQuestion();
      };
      $('cbtZoomBtn').onclick = () => openZoom($('cbtQuestionImg').src, state.session.ntaQDark);
      $('cbtQuestionImg').onclick = () => openZoom($('cbtQuestionImg').src, state.session.ntaQDark);

      // Practice Actions
      $('pracPrevBtn').onclick = () => { if (state.session.idx > 0) { state.session.idx--; renderPracticeQuestion(); } };
      $('pracNextBtn').onclick = () => { if (state.session.idx < state.session.questions.length - 1) { state.session.idx++; renderPracticeQuestion(); } };
      $('pracCheckBtn').onclick = () => {
        const s = state.session, q = s.questions[s.idx];
        if (!q) return;
        if (s.mode === 'practice') { s.revealed[q.id] = true; renderPracticeQuestion(); }
        else { s.statuses[q.id] = s.responses[q.id] ? 'answered' : 'not_answered'; if (s.idx < s.questions.length - 1) s.idx++; renderPracticeQuestion(); }
      };
      $('pracFinishBtn').onclick = finishSession;
      $('pracInvertBtn').onclick = () => { state.session.invertPractice = !state.session.invertPractice; renderPracticeQuestion(); };
      $('pracZoomBtn').onclick = () => openZoom($('pracQuestionImg').src, state.session.invertPractice);
      $('pracQuestionImg').onclick = () => openZoom($('pracQuestionImg').src, state.session.invertPractice);

      // Analysis Actions
      document.querySelectorAll('.an-pill-btn').forEach(b => { b.onclick = () => setAnalysisSub(b.dataset.asub); });
      $('anViewSolTopBtn').onclick = () => setAnalysisSub('solution');
      $('anBackFoldersBtn').onclick = () => showView('folders');
      $('anAllTestsBtn').onclick = () => showView('folders');
      $('anRetryBtn').onclick = () => {
        const snap = state.activeAttempt || getAttempts()[0];
        if (snap) openInstructions({ title: snap.title, mins: Math.max(15, Math.round(snap.questions.length * 2)), questions: snap.questions });
      };
      $('savedAttemptsSel').onchange = (e) => {
        const f = getAttempts().find(a => a.id === e.target.value);
        if (f) { state.activeAttempt = f; state.solIdx = 0; renderAnalysis(); }
      };

      // Bookmarks Actions
      $('bkPracticeBtn').onclick = () => {
        const bks = getBks();
        if (!bks.length) { toast('Bookmark some questions first!', 'warn'); return; }
        startSession({ title: 'Bookmarked Questions', mins: Math.max(15, bks.length * 2), questions: bks }, 'practice');
      };
      $('bkExportBtn').onclick = () => {
        const list = getBks();
        if (!list.length) { toast('Bookmark some questions first!', 'warn'); return; }
        const cards = list.map((q, i) => `<div style="background:#0e1426;border:1px solid #1e293b;border-radius:12px;padding:14px;margin-bottom:14px;"><div style="color:#fbbf24;font-weight:700;margin-bottom:8px;">Q.${i+1} — ${q.chapter || q.subject} (Key: ${q.answerKey || '—'})</div><img src="${getImgSrc(q)}" style="max-width:100%;border-radius:8px;${q.isDark ? '' : 'filter:invert(0.93) hue-rotate(180deg) contrast(1.2);'}" /></div>`).join('');
        const doc = '<' + '!DOCTYPE html><' + 'html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>EDUNITI Bookmarks</title></head><body style="background:#070a14;color:#e2e8f0;font-family:system-ui,sans-serif;max-width:780px;margin:0 auto;padding:18px;"><h2 style="color:#38bdf8;">EDUNITI Bookmarks (' + list.length + ')</h2>' + cards + '<' + '/body><' + '/html>';
        const u = URL.createObjectURL(new Blob([doc], { type: 'text/html' }));
        const a = document.createElement('a'); a.href = u; a.download = 'eduniti_bookmarked_questions.html'; a.click(); URL.revokeObjectURL(u);
      };

      // Zoom Modal + Vivo + Fullscreen
      $('zmInBtn').onclick = () => { zm = Math.min(320, zm + 30); $('zmImg').style.width = zm + '%'; $('zmPct').textContent = zm + '%'; };
      $('zmOutBtn').onclick = () => { zm = Math.max(80, zm - 30); $('zmImg').style.width = zm + '%'; $('zmPct').textContent = zm + '%'; };
      $('zmCloseBtn').onclick = () => $('zoomModal').classList.add('hidden');
      let vivo = false;
      $('vivoModeBtn').onclick = () => { vivo = !vivo; $('appShell').classList.toggle('vivo-shell', vivo); toast(vivo ? 'Vivo T3x 5G viewport ON' : 'Full-width mode ON'); };
      $('fullscreenBtn').onclick = async () => { try { if (!document.fullscreenElement) await document.documentElement.requestFullscreen(); else await document.exitFullscreen(); } catch {} };
    });
