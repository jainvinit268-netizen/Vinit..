EDUNITI — Complete Single Website ZIP (ALL 28 PDFs / 2,403 Questions)
=====================================================================
Everything is inside this ONE ZIP:
- index.html      : Main website & PWA entry (Practice + Classic NTA CBT, Bright & Dark)
- app.js          : Full app logic (Folders, NTA Instructions, Analysis, Saved Attempts, Bookmarks)
- bank.js         : All 2,403 questions metadata, 2,383 Official Keys, Chapters & Eduniti YouTube timestamps
- images/         : All 2,403 cropped WebP question images across all 28 PDFs
- manifest.json   : Installable Android/iOS PWA manifest
- icon.svg        : Custom EDUNITI hexagonal app icon
- sw.js           : Offline Service Worker

How to launch your website / install as app:
1. Extract this ZIP into a single folder.
2. Upload the extracted folder to https://app.netlify.com/drop (or GitHub Pages / Vercel).
3. Open your live https:// link in Chrome -> Menu (3 dots) -> Install app / Add to Home screen.
   (Using https:// enables direct inline YouTube video playback!)
